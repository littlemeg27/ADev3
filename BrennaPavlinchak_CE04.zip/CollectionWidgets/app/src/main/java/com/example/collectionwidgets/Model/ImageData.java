package com.example.collectionwidgets.Model;

import android.net.Uri;

// Brenna Pavlinchak
// AD3 - C202504
// ImageData

public class ImageData
{
    private final Uri uri;
    private final String name;

    public ImageData(Uri uri, String name)
    {
        this.uri = uri;
        this.name = name;
    }

    public Uri getUri()
    {
        return uri;
    }

    public String getName()
    {
        return name;
    }
}