package com.example.collectionwidgets.Operations;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.widget.RemoteViews;

import com.example.collectionwidgets.R;
import com.example.collectionwidgets.Service.FlipperWidgetService;

// Brenna Pavlinchak
// AD3 - C202504
// FlipperWidgetProvider

public class FlipperWidgetProvider extends AppWidgetProvider
{
    public static final String ACTION_VIEW_IMAGE = "com.example.collectionwidgets.FLIPPER_ACTION_VIEW_IMAGE";

    @Override
    public void onUpdate(Context context, AppWidgetManager appWidgetManager, int[] appWidgetIds)
    {
        for (int appWidgetId : appWidgetIds)
        {
            RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.flipper_widget_layout);
            Intent intent = new Intent(context, FlipperWidgetService.class);
            intent.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, appWidgetId);
            views.setRemoteAdapter(R.id.flipper_view, intent);

            Intent clickIntent = new Intent(context, FlipperWidgetProvider.class);
            clickIntent.setAction(ACTION_VIEW_IMAGE);
            views.setPendingIntentTemplate(R.id.flipper_view, PendingIntent.getBroadcast(context, 0, clickIntent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE));

            appWidgetManager.updateAppWidget(appWidgetId, views);
        }
    }

    @Override
    public void onReceive(Context context, Intent intent)
    {
        super.onReceive(context, intent);
        if (ACTION_VIEW_IMAGE.equals(intent.getAction()))
        {
            Uri imageUri = intent.getData();

            if (imageUri != null)
            {
                Intent viewIntent = new Intent(Intent.ACTION_VIEW);
                viewIntent.setData(imageUri);
                viewIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(viewIntent);
            }
        }
        else if (AppWidgetManager.ACTION_APPWIDGET_UPDATE.equals(intent.getAction()))
        {
            int[] appWidgetIds = intent.getIntArrayExtra(AppWidgetManager.EXTRA_APPWIDGET_IDS);

            if (appWidgetIds != null)
            {
                onUpdate(context, AppWidgetManager.getInstance(context), appWidgetIds);
            }
        }
    }
}