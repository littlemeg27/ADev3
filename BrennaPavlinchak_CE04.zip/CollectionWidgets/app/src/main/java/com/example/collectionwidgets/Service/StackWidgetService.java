package com.example.collectionwidgets.Service;

import android.content.Context;
import android.content.Intent;
import android.widget.RemoteViews;
import android.widget.RemoteViewsService;

import com.example.collectionwidgets.R;

// Brenna Pavlinchak
// AD3 - C202504
// StackWidgetService

public class StackWidgetService extends RemoteViewsService
{
    @Override
    public RemoteViewsFactory onGetViewFactory(Intent intent)
    {
        return new StackWidgetFactory(getApplicationContext(), intent);
    }

    static class StackWidgetFactory implements RemoteViewsService.RemoteViewsFactory
    {
        private Context context;

        public StackWidgetFactory(Context context, Intent intent)
        {
            this.context = context;
        }

        @Override
        public void onCreate()
        {
            // Initialize data
        }

        @Override
        public RemoteViews getViewAt(int position)
        {
            RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.stack_item_layout);
            return views;
        }

        @Override
        public void onDataSetChanged()
        {
            // Refresh data
        }

        @Override
        public void onDestroy()
        {
            // Clean up
        }

        @Override
        public int getCount()
        {
            return 0;
        }

        @Override
        public RemoteViews getLoadingView()
        {
            return null;
        }

        @Override
        public int getViewTypeCount()
        {
            return 1;
        }

        @Override
        public long getItemId(int position)
        {
            return position;
        }

        @Override
        public boolean hasStableIds()
        {
            return true;
        }
    }
}