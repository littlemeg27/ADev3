package com.example.collectionwidgets.Operations;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

import com.example.collectionwidgets.R;

import android.app.PendingIntent;
import android.content.Intent;
import android.os.Build;
import androidx.activity.result.contract.ActivityResultContracts;

// Brenna Pavlinchak
// AD3 - C202504
// MainActivity

public class MainActivity extends AppCompatActivity
{
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q)
        {
            Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            intent.setType("image/*");
            PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, intent, PendingIntent.FLAG_IMMUTABLE);
            registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), result ->
            {

            }).launch(Intent.createChooser(intent, "Select Image"));
        }
    }
}