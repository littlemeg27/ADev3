package com.example.collectionwidgets.Operations;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.widget.RemoteViews;

import com.example.collectionwidgets.R;
import com.example.collectionwidgets.Service.StackWidgetService;

// Brenna Pavlinchak
// AD3 - C202504
// StackWidgetProvider

public class StackWidgetProvider extends AppWidgetProvider
{
    public static final String ACTION_VIEW_IMAGE = "com.example.collectionwidgets.ACTION_VIEW_IMAGE";

    @Override
    public void onUpdate(Context context, AppWidgetManager appWidgetManager, int[] appWidgetIds)
    {
        for (int appWidgetId : appWidgetIds)
        {
            RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.stack_widget_layout);
            Intent intent = new Intent(context, StackWidgetService.class);
            intent.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, appWidgetId);
            views.setRemoteAdapter(R.id.stack_view, intent);

            Intent clickIntent = new Intent(context, StackWidgetProvider.class);
            clickIntent.setAction(ACTION_VIEW_IMAGE);
            views.setPendingIntentTemplate(R.id.stack_view, PendingIntent.getBroadcast(context, 0, clickIntent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE));

            appWidgetManager.updateAppWidget(appWidgetId, views);
        }
    }

    @Override
    public void onReceive(Context context, Intent intent)
    {
        super.onReceive(context, intent);
        if (ACTION_VIEW_IMAGE.equals(intent.getAction()))
        {
            Uri imageUri = intent.getData();
            if (imageUri != null)
            {
                Intent viewIntent = new Intent(Intent.ACTION_VIEW);
                viewIntent.setData(imageUri);
                viewIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(viewIntent);
            }
        }
    }
}